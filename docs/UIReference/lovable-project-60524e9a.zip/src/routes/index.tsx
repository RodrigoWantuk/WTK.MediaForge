import { createFileRoute } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import {
  ChevronDown,
  ChevronRight,
  Folder,
  Film,
  Camera,
  Monitor,
  Image as ImageIcon,
  Type,
  Radio,
  Circle,
  Layers as LayersIcon,
  Play,
  Square,
  Save,
  FolderOpen,
  FilePlus,
  Plus,
  Settings,
  Zap,
  Cpu,
  Activity,
  AlertTriangle,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  GripVertical,
  Search,
  Maximize2,
  Grid3x3,
  ZoomIn,
  ZoomOut,
  Link as LinkIcon,
  Sparkles,
  Trash2,
  ChevronUp,
  RotateCcw,
  Minus,
  X,
} from "lucide-react";

export const Route = createFileRoute("/")({
  component: StudioMock,
});

type IconType = React.ComponentType<{ className?: string; size?: number }>;
type Sel = { kind: string; name: string };

function StudioMock() {
  const [selection, setSelection] = useState<Sel>({ kind: "layer", name: "Lower Third" });
  const [bottomTab, setBottomTab] = useState("layers");
  const [engineRunning, setEngineRunning] = useState(true);

  return (
    <div className="flex h-screen w-screen flex-col bg-background text-text-primary select-none">
      <TitleBar engineRunning={engineRunning} />
      <ToolBar engineRunning={engineRunning} onToggleEngine={() => setEngineRunning((v) => !v)} />
      <div className="flex min-h-0 flex-1">
        <LeftPanel selection={selection} onSelect={setSelection} />
        <div className="flex min-w-0 flex-1 flex-col">
          <CanvasArea />
          <BottomPanel tab={bottomTab} onTab={setBottomTab} />
        </div>
        <RightInspector selection={selection} />
      </div>
      <StatusBar engineRunning={engineRunning} />
    </div>
  );
}

// ---------- Title bar ----------
function TitleBar({ engineRunning }: { engineRunning: boolean }) {
  const menus = ["File", "Edit", "View", "Scene", "Source", "Output", "Tools", "Help"];
  return (
    <div className="flex h-9 shrink-0 items-center border-b border-border bg-surface-2 pl-2 pr-1 text-[12px]">
      <div className="flex items-center gap-2 pr-3">
        <div className="grid size-5 place-items-center rounded-sm bg-accent/15 text-accent">
          <Sparkles size={12} />
        </div>
        <span className="font-semibold tracking-tight">WTK MediaForge Studio</span>
      </div>
      <div className="mx-2 h-4 w-px bg-border" />
      <div className="flex items-center gap-2 text-text-secondary">
        <span className="text-text-primary">Untitled Project</span>
        <span className="text-accent">*</span>
      </div>
      <div className="mx-2 h-4 w-px bg-border" />
      <nav className="flex items-center">
        {menus.map((m) => (
          <button
            key={m}
            className="rounded px-2 py-1 text-text-secondary transition hover:bg-surface-3 hover:text-text-primary"
          >
            {m}
          </button>
        ))}
      </nav>
      <div className="ml-auto flex items-center gap-1">
        <Indicator icon={Zap} label="Engine" value={engineRunning ? "Running" : "Stopped"} tone={engineRunning ? "success" : "muted"} pulse={engineRunning} />
        <Indicator icon={Activity} value="60.0 FPS" tone="default" mono />
        <Indicator icon={AlertTriangle} value="0 drop" tone="muted" mono />
        <Indicator icon={Cpu} label="GPU" value="42%" tone="default" mono />
        <div className="mx-1 h-4 w-px bg-border" />
        <WindowBtn icon={Minus} />
        <WindowBtn icon={Square} small />
        <WindowBtn icon={X} danger />
      </div>
    </div>
  );
}

function Indicator({
  icon: Icon,
  label,
  value,
  tone,
  pulse,
  mono,
}: {
  icon: IconType;
  label?: string;
  value: string;
  tone: "success" | "muted" | "default";
  pulse?: boolean;
  mono?: boolean;
}) {
  const toneCls = tone === "success" ? "text-success" : tone === "muted" ? "text-text-muted" : "text-text-secondary";
  return (
    <div className="flex items-center gap-1.5 rounded px-2 py-1 hover:bg-surface-3">
      <Icon size={12} className={toneCls} />
      {label ? <span className="text-text-muted">{label}:</span> : null}
      <span className={`${mono ? "mono" : ""} text-text-primary`}>{value}</span>
      {pulse ? <span className="pulse-dot inline-block size-1.5 rounded-full bg-success text-success" /> : null}
    </div>
  );
}

function WindowBtn({ icon: Icon, danger, small }: { icon: IconType; danger?: boolean; small?: boolean }) {
  return (
    <button className={`grid size-7 place-items-center rounded text-text-secondary transition ${danger ? "hover:bg-error hover:text-white" : "hover:bg-surface-3"}`}>
      <Icon size={small ? 10 : 12} />
    </button>
  );
}

// ---------- Toolbar ----------
function ToolBar({ engineRunning, onToggleEngine }: { engineRunning: boolean; onToggleEngine: () => void }) {
  return (
    <div className="flex h-11 shrink-0 items-center gap-1 border-b border-border bg-surface-1 px-2">
      <ToolBtn icon={FilePlus} label="New" />
      <ToolBtn icon={FolderOpen} label="Open" />
      <ToolBtn icon={Save} label="Save" />
      <Divider />
      <ToolBtn icon={Plus} label="Add Source" primary />
      <ToolBtn icon={LayersIcon} label="Add Scene" />
      <Divider />
      <ToolBtn icon={engineRunning ? Square : Play} label={engineRunning ? "Stop Engine" : "Start Engine"} onClick={onToggleEngine} tone={engineRunning ? "danger" : "success"} />
      <ToolBtn icon={Radio} label="Start Streaming" />
      <ToolBtn icon={Circle} label="Start Recording" />
      <div className="ml-auto">
        <ToolBtn icon={Settings} label="Settings" iconOnly />
      </div>
    </div>
  );
}

function Divider() {
  return <div className="mx-1 h-6 w-px bg-border" />;
}

function ToolBtn({
  icon: Icon,
  label,
  primary,
  tone,
  iconOnly,
  onClick,
}: {
  icon: IconType;
  label: string;
  primary?: boolean;
  tone?: "success" | "danger";
  iconOnly?: boolean;
  onClick?: () => void;
}) {
  const base = "flex h-8 items-center gap-1.5 rounded-md px-2.5 text-[12.5px] transition border";
  const styles = primary
    ? "border-accent/40 bg-accent/10 text-accent hover:bg-accent/20"
    : tone === "success"
      ? "border-success/30 bg-success/10 text-success hover:bg-success/20"
      : tone === "danger"
        ? "border-error/30 bg-error/10 text-error hover:bg-error/20"
        : "border-transparent text-text-secondary hover:bg-surface-2 hover:text-text-primary";
  return (
    <button onClick={onClick} className={`${base} ${styles}`} title={label}>
      <Icon size={14} />
      {!iconOnly && <span>{label}</span>}
    </button>
  );
}

// ---------- Left panel ----------
function LeftPanel({ selection, onSelect }: { selection: Sel; onSelect: (s: Sel) => void }) {
  return (
    <aside className="flex w-64 shrink-0 flex-col border-r border-border bg-surface-1">
      <PanelHeader title="Project Explorer">
        <button className="grid size-6 place-items-center rounded text-text-secondary hover:bg-surface-3 hover:text-text-primary">
          <Search size={13} />
        </button>
      </PanelHeader>
      <div className="min-h-0 flex-1 overflow-y-auto py-1 text-[12.5px]">
        <TreeGroup label="Scenes" defaultOpen count={3}>
          <TreeItem icon={LayersIcon} label="Main Scene" active={selection.kind === "scene" && selection.name === "Main Scene"} onClick={() => onSelect({ kind: "scene", name: "Main Scene" })} trailing={<Dot tone="success" />} />
          <TreeItem icon={LayersIcon} label="Interview" onClick={() => onSelect({ kind: "scene", name: "Interview" })} />
          <TreeItem icon={LayersIcon} label="Break BRB" onClick={() => onSelect({ kind: "scene", name: "Break BRB" })} />
        </TreeGroup>
        <TreeGroup label="Sources" defaultOpen count={5}>
          <TreeItem icon={Camera} label="Webcam" meta="BRIO" onClick={() => onSelect({ kind: "source", name: "Webcam" })} active={selection.kind === "source" && selection.name === "Webcam"} />
          <TreeItem icon={Monitor} label="Desktop Capture" meta="Disp 1" onClick={() => onSelect({ kind: "source", name: "Desktop Capture" })} />
          <TreeItem icon={ImageIcon} label="Logo.png" meta="Image" />
          <TreeItem icon={Type} label="Lower Third" meta="Text" />
          <TreeItem icon={Film} label="Intro.mp4" meta="Media" trailing={<Chip tone="warning">buffer</Chip>} />
        </TreeGroup>
        <TreeGroup label="Outputs" defaultOpen count={3}>
          <TreeItem icon={Monitor} label="Preview" meta="Local" trailing={<Dot tone="success" />} onClick={() => onSelect({ kind: "output", name: "Preview" })} />
          <TreeItem icon={Circle} label="Recording MP4" meta="H.264" trailing={<Dot tone="rec" pulse />} onClick={() => onSelect({ kind: "output", name: "Recording MP4" })} />
          <TreeItem icon={Radio} label="RTMP · Twitch" meta="6 Mb/s" trailing={<Dot tone="success" pulse />} onClick={() => onSelect({ kind: "output", name: "RTMP · Twitch" })} active={selection.kind === "output" && selection.name === "RTMP · Twitch"} />
        </TreeGroup>
        <TreeGroup label="Presets" count={2}>
          <TreeItem icon={Folder} label="1080p Streaming" />
          <TreeItem icon={Folder} label="YouTube 1080p60" />
        </TreeGroup>
        <TreeGroup label="Packages" count={2}>
          <TreeItem icon={Folder} label="Starter Pack" />
          <TreeItem icon={Folder} label="Brand Kit" trailing={<Chip tone="info">v2</Chip>} />
        </TreeGroup>
      </div>
      <div className="flex h-8 items-center gap-1 border-t border-border px-2">
        <button className="grid size-6 place-items-center rounded text-text-secondary hover:bg-surface-3 hover:text-text-primary"><Plus size={13} /></button>
        <button className="grid size-6 place-items-center rounded text-text-secondary hover:bg-surface-3 hover:text-text-primary"><Folder size={12} /></button>
        <button className="grid size-6 place-items-center rounded text-text-secondary hover:bg-surface-3 hover:text-text-primary"><Trash2 size={12} /></button>
        <span className="ml-auto text-[11px] text-text-muted">15 items</span>
      </div>
    </aside>
  );
}

function PanelHeader({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="flex h-9 shrink-0 items-center border-b border-border bg-surface-2 px-3">
      <span className="text-[11px] font-semibold uppercase tracking-wider text-text-secondary">{title}</span>
      <div className="ml-auto flex items-center gap-0.5">{children}</div>
    </div>
  );
}

function TreeGroup({ label, count, defaultOpen, children }: { label: string; count?: number; defaultOpen?: boolean; children: ReactNode }) {
  const [open, setOpen] = useState(!!defaultOpen);
  return (
    <div className="mb-1">
      <button onClick={() => setOpen((o) => !o)} className="flex w-full items-center gap-1 px-2 py-1 text-[11px] font-semibold uppercase tracking-wider text-text-muted hover:text-text-secondary">
        {open ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
        <span>{label}</span>
        {count !== undefined && <span className="mono ml-1 text-[10px] text-text-muted">{count}</span>}
      </button>
      {open && <div className="mt-0.5">{children}</div>}
    </div>
  );
}

function TreeItem({ icon: Icon, label, meta, active, trailing, onClick }: { icon: IconType; label: string; meta?: string; active?: boolean; trailing?: ReactNode; onClick?: () => void }) {
  return (
    <button onClick={onClick} className={`group flex w-full items-center gap-2 border-l-2 px-2 py-1 text-left transition ${active ? "border-accent bg-accent-soft/40 text-text-primary" : "border-transparent text-text-secondary hover:bg-surface-2 hover:text-text-primary"}`}>
      <Icon size={13} className={active ? "text-accent" : "text-text-muted"} />
      <span className="truncate">{label}</span>
      {meta && <span className="mono ml-auto truncate text-[10.5px] text-text-muted">{meta}</span>}
      {trailing && <span className="ml-1 flex items-center">{trailing}</span>}
    </button>
  );
}

function Dot({ tone, pulse }: { tone: "success" | "rec" | "warning"; pulse?: boolean }) {
  const color = tone === "success" ? "bg-success text-success" : tone === "rec" ? "bg-rec text-rec" : "bg-warning text-warning";
  return <span className={`inline-block size-1.5 rounded-full ${color} ${pulse ? "pulse-dot" : ""}`} />;
}

function Chip({ children, tone = "muted" }: { children: ReactNode; tone?: "muted" | "info" | "warning" }) {
  const cls = tone === "info" ? "bg-accent/15 text-accent border-accent/25" : tone === "warning" ? "bg-warning/15 text-warning border-warning/25" : "bg-surface-3 text-text-muted border-border";
  return <span className={`rounded border px-1.5 py-px text-[10px] uppercase tracking-wider ${cls}`}>{children}</span>;
}

// ---------- Canvas ----------
function CanvasArea() {
  return (
    <section className="flex min-h-0 flex-1 flex-col border-b border-border">
      <div className="flex h-9 shrink-0 items-center gap-2 border-b border-border bg-surface-1 px-3 text-[11.5px]">
        <span className="text-text-muted">Preview</span>
        <span className="mono text-text-secondary">·</span>
        <span className="mono text-text-secondary">Main Scene</span>
        <span className="mono text-text-muted">·</span>
        <span className="mono text-text-muted">1920×1080 · 16:9</span>
        <div className="ml-auto flex items-center gap-1">
          <IconBtn icon={ZoomOut} />
          <span className="mono w-10 text-center text-text-secondary">65%</span>
          <IconBtn icon={ZoomIn} />
          <Divider />
          <MiniBtn label="Fit" icon={Maximize2} />
          <MiniBtn label="100%" />
          <MiniBtn icon={Grid3x3} active />
          <MiniBtn label="Safe" />
        </div>
      </div>
      <div className="checker relative min-h-0 flex-1 overflow-hidden">
        <div className="absolute left-1/2 top-1/2 aspect-video w-[78%] -translate-x-1/2 -translate-y-1/2 overflow-hidden rounded-sm shadow-[0_20px_60px_rgba(0,0,0,0.55)] ring-1 ring-black/40">
          <div className="absolute inset-0 bg-gradient-to-br from-[#1c2740] via-[#0f1626] to-[#050810]" />
          <div className="absolute -left-16 top-10 size-64 rounded-full bg-accent/15 blur-3xl" />
          <div className="absolute right-10 bottom-0 size-72 rounded-full bg-[#7c5cff]/20 blur-3xl" />
          <div className="absolute inset-x-0 bottom-0 top-[18%] flex justify-center">
            <div className="relative h-full w-[55%]">
              <div className="absolute left-1/2 top-6 size-28 -translate-x-1/2 rounded-full bg-[#3a3226] shadow-[inset_0_-10px_20px_rgba(0,0,0,0.5)]" />
              <div className="absolute left-1/2 top-28 h-64 w-40 -translate-x-1/2 rounded-t-[50%] bg-[#141821]" />
            </div>
          </div>
          <div className="absolute right-6 top-5 flex items-center gap-2 rounded-md bg-black/40 px-3 py-1.5 backdrop-blur">
            <div className="grid size-5 place-items-center rounded-sm bg-accent/25 text-accent"><Sparkles size={11} /></div>
            <span className="text-[11px] font-semibold tracking-wider text-white/90">WTK</span>
          </div>
          <div className="absolute bottom-10 left-8 right-[40%]">
            <div className="relative rounded-sm bg-gradient-to-r from-black/70 to-black/10 py-3 pl-4 pr-8 backdrop-blur-sm">
              <div className="absolute left-0 top-0 h-full w-1 bg-accent" />
              <div className="text-[22px] font-bold uppercase tracking-wider text-white">Live Now</div>
              <div className="mono text-[11px] text-white/60">on air · main scene</div>
              <div className="pointer-events-none absolute -inset-1 border border-accent">
                {["-top-1 -left-1", "-top-1 left-1/2 -translate-x-1/2", "-top-1 -right-1", "top-1/2 -left-1 -translate-y-1/2", "top-1/2 -right-1 -translate-y-1/2", "-bottom-1 -left-1", "-bottom-1 left-1/2 -translate-x-1/2", "-bottom-1 -right-1"].map((pos) => (
                  <span key={pos} className={`absolute size-2 border border-accent bg-background ${pos}`} />
                ))}
              </div>
            </div>
          </div>
          <div className="absolute left-5 top-5 flex items-center gap-1.5 rounded-full bg-error/90 px-2 py-0.5 text-[10.5px] font-bold uppercase tracking-widest text-white shadow">
            <span className="pulse-dot inline-block size-1.5 rounded-full bg-white text-white" />
            Live
          </div>
        </div>
        <div className="mono absolute bottom-2 right-3 rounded bg-black/40 px-2 py-1 text-[10.5px] text-white/70 backdrop-blur">
          16.6 ms · frame 428,102
        </div>
      </div>
    </section>
  );
}

function IconBtn({ icon: Icon }: { icon: IconType }) {
  return (
    <button className="grid size-7 place-items-center rounded text-text-secondary hover:bg-surface-3 hover:text-text-primary">
      <Icon size={13} />
    </button>
  );
}

function MiniBtn({ icon: Icon, label, active }: { icon?: IconType; label?: string; active?: boolean }) {
  return (
    <button className={`flex h-7 items-center gap-1 rounded px-2 text-[11.5px] transition ${active ? "bg-accent/15 text-accent" : "text-text-secondary hover:bg-surface-3 hover:text-text-primary"}`}>
      {Icon && <Icon size={12} />}
      {label}
    </button>
  );
}

// ---------- Bottom panel ----------
function BottomPanel({ tab, onTab }: { tab: string; onTab: (t: string) => void }) {
  const tabs = [
    { id: "layers", label: "Layers", count: 4 },
    { id: "effects", label: "Effects", count: 2 },
    { id: "timeline", label: "Timeline" },
    { id: "diag", label: "Diagnostics" },
    { id: "perf", label: "Performance" },
    { id: "output", label: "Output Monitor" },
    { id: "audio", label: "Audio Mixer", chip: "beta" },
  ];
  return (
    <section className="flex h-[240px] shrink-0 flex-col bg-surface-1">
      <div className="flex h-9 shrink-0 items-center gap-0 border-b border-border bg-surface-2 px-1">
        {tabs.map((t) => (
          <button key={t.id} onClick={() => onTab(t.id)} className={`flex h-9 items-center gap-1.5 border-b-2 px-3 text-[12px] transition ${tab === t.id ? "border-accent text-text-primary" : "border-transparent text-text-secondary hover:text-text-primary"}`}>
            <span>{t.label}</span>
            {t.count !== undefined && <span className="mono text-[10.5px] text-text-muted">{t.count}</span>}
            {t.chip && <Chip tone="info">{t.chip}</Chip>}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-1 pr-2">
          <IconBtn icon={Plus} />
          <IconBtn icon={ChevronUp} />
        </div>
      </div>
      <div className="min-h-0 flex-1 overflow-auto">
        {tab === "layers" && <LayersView />}
        {tab === "effects" && <EffectsView />}
        {tab === "diag" && <DiagnosticsView />}
        {tab === "perf" && <PerformanceView />}
        {tab === "output" && <OutputMonitorView />}
        {tab === "audio" && <AudioMixerView />}
        {tab === "timeline" && <EmptyState label="Timeline coming in a later release" />}
      </div>
    </section>
  );
}

function LayersView() {
  const rows = [
    { n: 1, name: "Lower Third", type: "Text", src: '"Live Now"', selected: true, locked: true },
    { n: 2, name: "Logo.png", type: "Image", src: "Logo.png" },
    { n: 3, name: "Webcam", type: "Video", src: "Logitech BRIO" },
    { n: 4, name: "Desktop Capture", type: "Video", src: "\\\\.\\DISPLAY1 (1920×1080)" },
  ];
  return (
    <div className="w-full">
      <div className="grid grid-cols-[24px_28px_28px_44px_32px_1fr_100px_1fr] items-center gap-2 border-b border-border bg-surface-2 px-2 py-1.5 text-[10.5px] uppercase tracking-wider text-text-muted">
        <span /><span /><span /><span>#</span><span /><span>Name</span><span>Type</span><span>Source</span>
      </div>
      {rows.map((r) => (
        <div key={r.n} className={`grid grid-cols-[24px_28px_28px_44px_32px_1fr_100px_1fr] items-center gap-2 border-b border-border/60 px-2 py-1.5 text-[12px] transition hover:bg-surface-2 ${r.selected ? "bg-accent-soft/25" : ""}`}>
          <button className="grid size-5 place-items-center text-text-muted hover:text-text-primary"><GripVertical size={12} /></button>
          <button className="grid size-5 place-items-center text-text-secondary hover:text-text-primary"><Eye size={13} /></button>
          <button className="grid size-5 place-items-center text-text-muted hover:text-text-primary">{r.locked ? <Lock size={12} /> : <Unlock size={12} />}</button>
          <span className="mono text-text-muted">{r.n}</span>
          <div className="grid size-6 place-items-center rounded-sm bg-surface-3 text-text-muted">
            {r.type === "Text" ? <Type size={12} /> : r.type === "Image" ? <ImageIcon size={12} /> : <Film size={12} />}
          </div>
          <span className="truncate text-text-primary">{r.name}</span>
          <span className="text-text-secondary">{r.type}</span>
          <span className="mono truncate text-text-secondary">{r.src}</span>
        </div>
      ))}
    </div>
  );
}

function EffectsView() {
  return (
    <div className="space-y-2 p-3">
      <EffectCard name="Chroma Key" enabled />
      <EffectCard name="Blur" enabled={false} />
      <button className="flex w-full items-center justify-center gap-1.5 rounded border border-dashed border-border py-2 text-[12px] text-text-secondary hover:border-accent hover:text-accent">
        <Plus size={13} /> Add effect
      </button>
    </div>
  );
}

function EffectCard({ name, enabled }: { name: string; enabled: boolean }) {
  return (
    <div className="rounded border border-border bg-surface-2">
      <div className="flex items-center gap-2 px-3 py-2">
        <GripVertical size={12} className="text-text-muted" />
        <button className={`relative h-4 w-7 rounded-full border transition ${enabled ? "border-accent bg-accent/40" : "border-border bg-surface-3"}`}>
          <span className={`absolute top-0.5 size-3 rounded-full transition ${enabled ? "left-3.5 bg-accent" : "left-0.5 bg-text-muted"}`} />
        </button>
        <span className={enabled ? "text-text-primary" : "text-text-muted"}>{name}</span>
        <div className="ml-auto flex items-center gap-1">
          <button className="grid size-6 place-items-center rounded text-text-muted hover:bg-surface-3 hover:text-text-secondary"><RotateCcw size={12} /></button>
          <button className="grid size-6 place-items-center rounded text-text-muted hover:bg-surface-3 hover:text-text-secondary"><Settings size={12} /></button>
        </div>
      </div>
      {enabled && name === "Chroma Key" && (
        <div className="grid grid-cols-2 gap-3 border-t border-border px-3 py-2">
          <PropRow label="Key color">
            <div className="flex items-center gap-2">
              <div className="size-5 rounded border border-border-strong bg-[#1cd67c]" />
              <span className="mono text-[11px] text-text-secondary">#1CD67C</span>
            </div>
          </PropRow>
          <PropRow label="Similarity"><Slider value={42} /></PropRow>
          <PropRow label="Smoothness"><Slider value={18} /></PropRow>
          <PropRow label="Spill"><Slider value={30} /></PropRow>
        </div>
      )}
    </div>
  );
}

function DiagnosticsView() {
  const logs = [
    { t: "10:42:11", lvl: "info", cat: "engine", msg: "Vulkan backend initialized · adapter NVIDIA RTX 4070" },
    { t: "10:42:12", lvl: "info", cat: "source", msg: "Webcam 'Logitech BRIO' opened at 1920x1080@60" },
    { t: "10:42:14", lvl: "warn", cat: "output", msg: "RTMP · Twitch: reconnect attempted after 1 dropped packet" },
    { t: "10:42:15", lvl: "info", cat: "scene", msg: "Main Scene composed · 4 layers · 2 effects" },
    { t: "10:42:16", lvl: "info", cat: "output", msg: "Recording MP4 started · /Recordings/2026-07-04.mp4" },
  ];
  return (
    <div className="mono">
      {logs.map((l, i) => (
        <div key={i} className="grid grid-cols-[70px_50px_80px_1fr] items-center gap-2 border-b border-border/50 px-3 py-1.5 text-[11.5px]">
          <span className="text-text-muted">{l.t}</span>
          <span className={l.lvl === "warn" ? "text-warning" : l.lvl === "error" ? "text-error" : "text-success"}>{l.lvl.toUpperCase()}</span>
          <span className="text-accent">{l.cat}</span>
          <span className="truncate text-text-secondary">{l.msg}</span>
        </div>
      ))}
    </div>
  );
}

function PerformanceView() {
  return (
    <div className="grid h-full grid-cols-4 gap-2 p-3">
      <Metric label="Render FPS" value="60.0" sub="target 60" tone="success" />
      <Metric label="Frame time" value="16.6" sub="ms · p99 18.2" />
      <Metric label="Dropped" value="0" sub="last 60s" tone="success" />
      <Metric label="GPU / VRAM" value="42%" sub="1.8 / 12 GB" />
      <div className="col-span-4 rounded border border-border bg-surface-2 p-3">
        <div className="mb-2 flex items-center justify-between text-[11px] text-text-muted">
          <span>Frame time (ms) · last 120 frames</span>
          <span className="mono">min 14.9 · avg 16.4 · max 21.1</span>
        </div>
        <Sparkline />
      </div>
    </div>
  );
}

function Metric({ label, value, sub, tone }: { label: string; value: string; sub: string; tone?: "success" }) {
  return (
    <div className="rounded border border-border bg-surface-2 p-3">
      <div className="text-[11px] uppercase tracking-wider text-text-muted">{label}</div>
      <div className={`mono mt-1 text-2xl font-semibold ${tone === "success" ? "text-success" : "text-text-primary"}`}>{value}</div>
      <div className="mono mt-1 text-[11px] text-text-muted">{sub}</div>
    </div>
  );
}

function Sparkline() {
  const pts = Array.from({ length: 60 }, (_, i) => 16 + Math.sin(i * 0.4) * 1.5 + (i % 9 === 0 ? 3 : 0));
  const max = 22;
  const w = 100;
  const h = 40;
  const path = pts.map((p, i) => `${i === 0 ? "M" : "L"}${(i / (pts.length - 1)) * w},${h - (p / max) * h}`).join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" className="h-24 w-full">
      <defs>
        <linearGradient id="g" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="oklch(0.72 0.15 235)" stopOpacity="0.35" />
          <stop offset="100%" stopColor="oklch(0.72 0.15 235)" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={`${path} L${w},${h} L0,${h} Z`} fill="url(#g)" />
      <path d={path} fill="none" stroke="oklch(0.72 0.15 235)" strokeWidth="0.6" />
    </svg>
  );
}

function OutputMonitorView() {
  const outs = [
    { name: "Preview", kind: "Local", bitrate: "—", fps: "60.0", status: "running" },
    { name: "Recording MP4", kind: "H.264 · MP4", bitrate: "12.0 Mb/s", fps: "60.0", status: "recording" },
    { name: "RTMP · Twitch", kind: "H.264 · RTMP", bitrate: "5.98 Mb/s", fps: "60.0", status: "live" },
    { name: "Virtual Camera", kind: "System", bitrate: "—", fps: "—", status: "planned" },
  ];
  return (
    <div>
      <div className="grid grid-cols-[1fr_1fr_120px_80px_120px_60px] gap-2 border-b border-border bg-surface-2 px-3 py-1.5 text-[10.5px] uppercase tracking-wider text-text-muted">
        <span>Output</span><span>Type</span><span>Bitrate</span><span>FPS</span><span>Status</span><span />
      </div>
      {outs.map((o) => (
        <div key={o.name} className="grid grid-cols-[1fr_1fr_120px_80px_120px_60px] items-center gap-2 border-b border-border/60 px-3 py-2 text-[12px]">
          <span className="text-text-primary">{o.name}</span>
          <span className="text-text-secondary">{o.kind}</span>
          <span className="mono text-text-secondary">{o.bitrate}</span>
          <span className="mono text-text-secondary">{o.fps}</span>
          <span>
            {o.status === "planned" ? <Chip tone="info">planned</Chip>
              : o.status === "live" ? <span className="flex items-center gap-1.5 text-success"><Dot tone="success" pulse /> Live</span>
              : o.status === "recording" ? <span className="flex items-center gap-1.5 text-error"><Dot tone="rec" pulse /> Recording</span>
              : <span className="flex items-center gap-1.5 text-success"><Dot tone="success" /> Running</span>}
          </span>
          <button className={`grid size-6 place-items-center rounded ${o.status === "planned" ? "cursor-not-allowed text-text-muted opacity-50" : "text-text-secondary hover:bg-surface-3 hover:text-text-primary"}`}>
            {o.status === "planned" ? <Play size={12} /> : <Square size={12} />}
          </button>
        </div>
      ))}
    </div>
  );
}

function AudioMixerView() {
  const channels = [
    { name: "Mic/Aux", level: 0.65, db: "-4.6" },
    { name: "Desktop", level: 0.55, db: "-8.1" },
    { name: "Webcam", level: 0.7, db: "-3.2" },
    { name: "Master", level: 0.85, db: "0.0" },
  ];
  return (
    <div className="flex h-full items-stretch gap-3 p-3">
      {channels.map((c) => (
        <div key={c.name} className="flex w-32 flex-col rounded border border-border bg-surface-2 p-2">
          <div className="flex items-center justify-between text-[11px] text-text-secondary">
            <span>{c.name}</span>
            <Settings size={11} className="text-text-muted" />
          </div>
          <div className="mt-2 flex flex-1 gap-1">
            <div className="relative w-3 rounded-sm bg-surface-3">
              <div className="absolute bottom-0 left-0 right-0 rounded-sm bg-gradient-to-t from-success via-warning to-error" style={{ height: `${c.level * 100}%` }} />
            </div>
            <div className="relative w-3 rounded-sm bg-surface-3">
              <div className="absolute bottom-0 left-0 right-0 rounded-sm bg-gradient-to-t from-success via-warning to-error" style={{ height: `${c.level * 100 - 5}%` }} />
            </div>
            <div className="relative flex-1">
              <div className="absolute left-1/2 top-0 h-full w-px -translate-x-1/2 bg-border-strong" />
              <div className="absolute left-1/2 h-4 w-6 -translate-x-1/2 rounded-sm border border-border-strong bg-surface-3 shadow" style={{ top: `${(1 - c.level) * 100}%` }} />
            </div>
          </div>
          <div className="mono mt-2 text-center text-[11px] text-text-secondary">{c.db} dB</div>
        </div>
      ))}
    </div>
  );
}

function EmptyState({ label }: { label: string }) {
  return <div className="flex h-full items-center justify-center text-[12px] text-text-muted">{label}</div>;
}

// ---------- Right inspector ----------
function RightInspector({ selection }: { selection: Sel }) {
  return (
    <aside className="flex w-[320px] shrink-0 flex-col border-l border-border bg-surface-1">
      <PanelHeader title="Inspector" />
      <div className="flex h-11 shrink-0 items-center gap-2 border-b border-border bg-surface-2 px-3">
        <div className="grid size-6 place-items-center rounded-sm bg-accent/15 text-accent">
          {selection.kind === "layer" ? <Type size={13} /> : selection.kind === "source" ? <Camera size={13} /> : selection.kind === "output" ? <Radio size={13} /> : <LayersIcon size={13} />}
        </div>
        <div className="min-w-0">
          <div className="truncate text-[12px] text-text-primary">{selection.name}</div>
          <div className="text-[10.5px] uppercase tracking-wider text-text-muted">{selection.kind}</div>
        </div>
        <div className="ml-auto"><IconBtn icon={Lock} /></div>
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto">
        {selection.kind === "layer" && <LayerInspector />}
        {selection.kind === "source" && <SourceInspector />}
        {selection.kind === "scene" && <SceneInspector />}
        {selection.kind === "output" && <OutputInspector />}
      </div>
    </aside>
  );
}

function InspectorSection({ title, children, action }: { title: string; children: ReactNode; action?: ReactNode }) {
  return (
    <div className="border-b border-border">
      <div className="flex h-8 items-center px-3">
        <span className="text-[10.5px] font-semibold uppercase tracking-wider text-text-muted">{title}</span>
        <div className="ml-auto">{action}</div>
      </div>
      <div className="space-y-2 px-3 pb-3">{children}</div>
    </div>
  );
}

function PropRow({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="grid grid-cols-[80px_1fr] items-center gap-2">
      <span className="text-[11.5px] text-text-secondary">{label}</span>
      {children}
    </div>
  );
}

function NumField({ value, unit }: { value: string; unit?: string }) {
  return (
    <div className="flex h-7 items-center rounded border border-border-strong bg-surface-2 px-2 text-[12px]">
      <input defaultValue={value} className="mono w-full bg-transparent text-text-primary outline-none" />
      {unit && <span className="mono text-[10.5px] text-text-muted">{unit}</span>}
    </div>
  );
}

function Slider({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="relative h-1.5 flex-1 rounded-full bg-surface-3">
        <div className="absolute inset-y-0 left-0 rounded-full bg-accent" style={{ width: `${value}%` }} />
        <div className="absolute top-1/2 size-3 -translate-x-1/2 -translate-y-1/2 rounded-full border border-accent bg-background" style={{ left: `${value}%` }} />
      </div>
      <span className="mono w-10 text-right text-[11px] text-text-secondary">{value}</span>
    </div>
  );
}

function Select({ value }: { value: string }) {
  return (
    <button className="flex h-7 items-center rounded border border-border-strong bg-surface-2 px-2 text-[12px] text-text-primary">
      <span>{value}</span>
      <ChevronDown size={12} className="ml-auto text-text-muted" />
    </button>
  );
}

function LayerInspector() {
  return (
    <>
      <InspectorSection title="Transform">
        <PropRow label="Position">
          <div className="flex items-center gap-1">
            <NumField value="120.0" />
            <NumField value="820.0" />
            <button className="grid size-6 place-items-center rounded text-text-muted hover:bg-surface-3 hover:text-text-primary"><LinkIcon size={12} /></button>
          </div>
        </PropRow>
        <PropRow label="Size">
          <div className="flex items-center gap-1">
            <NumField value="760.0" />
            <NumField value="180.0" />
            <button className="grid size-6 place-items-center rounded text-accent hover:bg-surface-3"><LinkIcon size={12} /></button>
          </div>
        </PropRow>
        <PropRow label="Rotation"><Slider value={50} /></PropRow>
        <PropRow label="Opacity"><Slider value={100} /></PropRow>
        <PropRow label="Blend"><Select value="Normal" /></PropRow>
      </InspectorSection>
      <InspectorSection title="Crop">
        <div className="grid grid-cols-2 gap-2">
          <PropRow label="Left"><NumField value="0" unit="px" /></PropRow>
          <PropRow label="Top"><NumField value="0" unit="px" /></PropRow>
          <PropRow label="Right"><NumField value="0" unit="px" /></PropRow>
          <PropRow label="Bottom"><NumField value="0" unit="px" /></PropRow>
        </div>
      </InspectorSection>
      <InspectorSection title="Effects" action={<button className="flex h-6 items-center gap-1 rounded px-1.5 text-[11px] text-accent hover:bg-accent/10"><Plus size={11} /> Add</button>}>
        <div className="rounded border border-border bg-surface-2 px-2 py-1.5">
          <div className="flex items-center gap-2 text-[12px]">
            <Dot tone="success" />
            <span>Chroma Key</span>
            <div className="ml-auto flex items-center gap-1">
              <button className="text-text-muted hover:text-text-primary"><Eye size={12} /></button>
              <button className="text-text-muted hover:text-text-primary"><Settings size={12} /></button>
            </div>
          </div>
        </div>
        <div className="rounded border border-border bg-surface-2 px-2 py-1.5 opacity-70">
          <div className="flex items-center gap-2 text-[12px]">
            <span className="size-1.5 rounded-full bg-text-muted" />
            <span className="text-text-muted">Blur</span>
            <div className="ml-auto flex items-center gap-1">
              <button className="text-text-muted hover:text-text-primary"><EyeOff size={12} /></button>
              <button className="text-text-muted hover:text-text-primary"><Settings size={12} /></button>
            </div>
          </div>
        </div>
      </InspectorSection>
    </>
  );
}

function SourceInspector() {
  return (
    <>
      <InspectorSection title="Device">
        <PropRow label="Type"><Select value="Webcam" /></PropRow>
        <PropRow label="Device"><Select value="Logitech BRIO" /></PropRow>
        <PropRow label="Resolution"><Select value="1920 × 1080" /></PropRow>
        <PropRow label="Frame rate"><Select value="60 fps" /></PropRow>
      </InspectorSection>
      <InspectorSection title="Status">
        <div className="flex items-center gap-2 text-[12px]">
          <Dot tone="success" pulse />
          <span className="text-text-primary">Streaming · 60.0 fps</span>
        </div>
        <div className="mono text-[11px] text-text-muted">buffer 2 frames · 0 dropped</div>
        <button className="mt-1 flex h-7 w-full items-center justify-center gap-1.5 rounded border border-border-strong bg-surface-2 text-[12px] text-text-secondary hover:bg-surface-3">
          <RotateCcw size={12} /> Reconnect
        </button>
      </InspectorSection>
    </>
  );
}

function SceneInspector() {
  return (
    <>
      <InspectorSection title="Canvas">
        <PropRow label="Size">
          <div className="flex items-center gap-1"><NumField value="1920" /><NumField value="1080" /></div>
        </PropRow>
        <PropRow label="FPS"><Select value="60" /></PropRow>
        <PropRow label="Background">
          <div className="flex items-center gap-2">
            <div className="size-5 rounded border border-border-strong bg-black" />
            <span className="mono text-[11px] text-text-secondary">#000000</span>
          </div>
        </PropRow>
      </InspectorSection>
      <InspectorSection title="Linked outputs">
        <div className="text-[12px] text-text-secondary">Preview · Recording MP4 · RTMP Twitch</div>
      </InspectorSection>
    </>
  );
}

function OutputInspector() {
  return (
    <>
      <InspectorSection title="Destination">
        <PropRow label="Type"><Select value="RTMP" /></PropRow>
        <PropRow label="Server">
          <div className="flex h-7 items-center rounded border border-border-strong bg-surface-2 px-2">
            <span className="mono truncate text-[11.5px] text-text-secondary">rtmp://live.twitch.tv/app</span>
          </div>
        </PropRow>
        <PropRow label="Stream key">
          <div className="flex h-7 items-center rounded border border-border-strong bg-surface-2 px-2">
            <span className="mono flex-1 text-[11.5px] text-text-secondary">••••••••••••</span>
            <Eye size={12} className="text-text-muted" />
          </div>
        </PropRow>
      </InspectorSection>
      <InspectorSection title="Encoder">
        <PropRow label="Codec"><Select value="H.264 (NVENC)" /></PropRow>
        <PropRow label="Bitrate"><NumField value="6000" unit="kb/s" /></PropRow>
        <PropRow label="Keyframe"><NumField value="2" unit="s" /></PropRow>
        <PropRow label="Preset"><Select value="Quality" /></PropRow>
      </InspectorSection>
      <InspectorSection title="Health">
        <div className="flex items-center gap-2 text-[12px]">
          <Dot tone="success" pulse />
          <span className="text-text-primary">Live · 5.98 Mb/s</span>
        </div>
        <div className="mono text-[11px] text-text-muted">rtt 42 ms · 0 dropped · 12 min uptime</div>
      </InspectorSection>
    </>
  );
}

// ---------- Status bar ----------
type StatusItem = { icon?: IconType; label: string; tone: "success" | "muted" | "default"; mono?: boolean };

function StatusBar({ engineRunning }: { engineRunning: boolean }) {
  const items: StatusItem[] = [
    { icon: Zap, label: engineRunning ? "Running" : "Stopped", tone: engineRunning ? "success" : "muted" },
    { label: "Vulkan", tone: "default", mono: true },
    { label: "60.0 FPS", tone: "default", mono: true },
    { label: "16.6 ms", tone: "default", mono: true },
    { label: "0 dropped", tone: "success", mono: true },
    { label: "Scene: Main", tone: "default" },
    { label: "Outputs: 2 active", tone: "success" },
    { label: "0 warnings", tone: "muted" },
  ];
  return (
    <div className="flex h-7 shrink-0 items-center gap-0 border-t border-border bg-surface-2 px-2 text-[11px]">
      {items.map((it, i) => {
        const Icon = it.icon;
        const toneCls = it.tone === "success" ? "text-success" : it.tone === "muted" ? "text-text-muted" : "text-text-secondary";
        return (
          <div key={i} className="flex items-center gap-1.5 px-2">
            {Icon && <Icon size={11} className={toneCls} />}
            <span className={`${it.mono ? "mono" : ""} ${toneCls}`}>{it.label}</span>
            {i < items.length - 1 && <span className="ml-2 h-3 w-px bg-border" />}
          </div>
        );
      })}
      <div className="mono ml-auto px-2 text-text-muted">WTK MediaForge Studio · v0.1.0-preview</div>
    </div>
  );
}
